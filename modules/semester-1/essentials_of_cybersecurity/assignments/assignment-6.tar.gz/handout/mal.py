import json

'''
Code that Eve is going to be running. You are supposed to fill this.
Eve gets the JSON string that Alice is sending to the bank and here
just returns the same.
'''
def eve(jmsg):
    return json.dumps(msg)
